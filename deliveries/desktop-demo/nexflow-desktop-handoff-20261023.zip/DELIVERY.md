# 电脑版源码交付包

打包日期：2026-10-23。
来源：PR #27，源码提交 `8fdcac4384e1f295c9996096e9ea986ca8ad12d1`（已合并）。
这是该次交付的源码快照，不自动包含后续 main 的更新。

请先阅读 docs/desktop-integration/quickstart.md 创建本机虚拟环境并安装依赖，再阅读 project-handoff.md 与 demo-script.md。
包内文档保留提交时的状态描述；远程提交与合并状态以 GitHub 为准。
购买模块及积分账户接口在该快照中仍待接入，不能视为购买取餐全流程已完成。

SOURCE-MANIFEST.json 记录每个源码文件的 SHA256。
不含 .git、.venv、真实 .env、运行数据库或原工作区的额外材料；backend/.env.example 为配置模板。
